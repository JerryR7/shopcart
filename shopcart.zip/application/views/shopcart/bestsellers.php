<section id="bestsellers" class="color-bg wow fadeInUp">
    <div class="container">
        <h1 class="section-title">暢銷商品</h1>

        <div class="product-grid-holder medium">
            <div class="col-xs-12 col-md-7 no-margin">

                <div class="row no-margin">
                    <div class="col-xs-12 col-sm-4 no-margin product-item-holder size-medium hover">
                        <div class="product-item">
                            <div class="image">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-05.jpg" />
                            </div>
                            <div class="body">
                                <div class="label-discount clear"></div>
                                <div class="title">
                                    <a href="javascript:undefined">beats studio headphones official one</a>
                                </div>
                                <div class="brand">beats</div>
                            </div>
                            <div class="prices">

                                <div class="price-current text-right">$1199.00</div>
                            </div>
                            <div class="hover-area">
                                <input type="hidden" id="product_id" class="product_id" value="2" />
                                <div class="add-cart-button">
                                    <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
                                </div>
                                <div class="wish-compare">
                                    <a class="btn-add-to-wishlist  add_favor" href="javascript:undefined">加入喜歡清單</a>
                                    <a class="btn-add-to-compare  add_compare" href="javascript:undefined">加入比較</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.product-item-holder -->

                    <div class="col-xs-12 col-sm-4 no-margin product-item-holder size-medium hover">
                        <div class="product-item">
                            <div class="image">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-06.jpg" />
                            </div>
                            <div class="body">
                                <div class="label-discount clear"></div>
                                <div class="title">
                                    <a href="javascript:undefined">playstasion 4 with four games and pad</a>
                                </div>
                                <div class="brand">acer</div>
                            </div>
                            <div class="prices">
                                <div class="price-current text-right">$1199.00</div>
                            </div>
                            <div class="hover-area">
                                <input type="hidden" id="product_id" class="product_id" value="2" />
                                <div class="add-cart-button">
                                    <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
                                </div>
                                <div class="wish-compare">
                                    <a class="btn-add-to-wishlist  add_favor" href="javascript:undefined">加入喜歡清單</a>
                                    <a class="btn-add-to-compare  add_compare" href="javascript:undefined">加入比較</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.product-item-holder -->

                    <div class="col-xs-12 col-sm-4 no-margin product-item-holder size-medium hover">
                        <div class="product-item">
                            <div class="image">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-07.jpg" />
                            </div>
                            <div class="body">
                                <div class="label-discount clear"></div>
                                <div class="title">
                                    <a href="javascript:undefined">EOS rebel t5i DSLR Camera with 18-55mm IS STM lens</a>
                                </div>
                                <div class="brand">canon</div>
                            </div>
                            <div class="prices">
                                <div class="price-current text-right">$1199.00</div>
                            </div>
                            <div class="hover-area">
                                <input type="hidden" id="product_id" class="product_id" value="2" />
                                <div class="add-cart-button">
                                    <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
                                </div>
                                <div class="wish-compare">
                                    <a class="btn-add-to-wishlist add_favor" href="javascript:undefined">加入喜歡清單</a>
                                    <a class="btn-add-to-compare  add_compare" href="javascript:undefined">加入比較</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.product-item-holder -->
                </div><!-- /.row -->

                <div class="row no-margin">

                    <div class="col-xs-12 col-sm-4 no-margin product-item-holder size-medium hover">
                        <div class="product-item">
                            <div class="image">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-08.jpg" />
                            </div>
                            <div class="body">
                                <div class="label-discount clear"></div>
                                <div class="title">
                                    <a href="javascript:undefined">fitbit zip wireless activity tracker - lime</a>
                                </div>
                                <div class="brand">fitbit zip</div>
                            </div>
                            <div class="prices">
                                <div class="price-current text-right">$1199.00</div>
                            </div>
                            <div class="hover-area">
                                <input type="hidden" id="product_id" class="product_id" value="2" />
                                <div class="add-cart-button">
                                    <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
                                </div>
                                <div class="wish-compare">
                                    <a class="btn-add-to-wishlist  add_favor" href="javascript:undefined">加入喜歡清單</a>
                                    <a class="btn-add-to-compare  add_compare" href="javascript:undefined">加入比較</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.product-item-holder -->

                    <div class="col-xs-12 col-sm-4 no-margin product-item-holder size-medium hover">
                        <div class="product-item">
                            <div class="image">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-09.jpg" />
                            </div>
                            <div class="body">
                                <div class="label-discount clear"></div>
                                <div class="title">
                                    <a href="javascript:undefined">PowerShot elph 115 16MP digital camera</a>
                                </div>
                                <div class="brand">canon</div>
                            </div>
                            <div class="prices">
                                <div class="price-current text-right">$1199.00</div>
                            </div>
                            <div class="hover-area">
                                <input type="hidden" id="product_id" class="product_id" value="2" />
                                <div class="add-cart-button">
                                    <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
                                </div>
                                <div class="wish-compare">
                                    <a class="btn-add-to-wishlist  add_favor" href="javascript:undefined">加入喜歡清單</a>
                                    <a class="btn-add-to-compare  add_compare" href="javascript:undefined">加入比較</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.product-item-holder -->

                    <div class="col-xs-12 col-sm-4 no-margin product-item-holder size-medium hover">
                        <div class="product-item">
                            <div class="image">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-10.jpg" />
                            </div>
                            <div class="body">
                                <div class="label-discount clear"></div>
                                <div class="title">
                                    <a href="javascript:undefined">netbook acer travelMate b113-E-10072</a>
                                </div>
                                <div class="brand">acer</div>
                            </div>
                            <div class="prices">
                                <div class="price-current text-right">$1199.00</div>
                            </div>
                            <div class="hover-area">
                                <input type="hidden" id="product_id" class="product_id" value="2" />
                                <div class="add-cart-button">
                                    <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
                                </div>
                                <div class="wish-compare">
                                    <a class="btn-add-to-wishlist  add_favor" href="javascript:undefined">加入喜歡清單</a>
                                    <a class="btn-add-to-compare  add_compare" href="javascript:undefined">加入比較</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.product-item-holder -->

                </div><!-- /.row -->
            </div><!-- /.col -->
            <div class="col-xs-12 col-md-5 no-margin">
                <div class="product-item-holder size-big single-product-gallery small-gallery">

                    <div id="best-seller-single-product-slider" class="single-product-slider owl-carousel">
                        <div class="single-product-gallery-item" id="slide1">
                            <a data-rel="prettyphoto" href="images/products/product-gallery-01.jpg">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-gallery-01.jpg" />
                            </a>
                        </div><!-- /.single-product-gallery-item -->

                        <div class="single-product-gallery-item" id="slide2">
                            <a data-rel="prettyphoto" href="images/products/product-gallery-01.jpg">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-gallery-01.jpg" />
                            </a>
                        </div><!-- /.single-product-gallery-item -->

                        <div class="single-product-gallery-item" id="slide3">
                            <a data-rel="prettyphoto" href="images/products/product-gallery-01.jpg">
                                <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-gallery-01.jpg" />
                            </a>
                        </div><!-- /.single-product-gallery-item -->
                    </div><!-- /.single-product-slider -->

                    <div class="gallery-thumbs clearfix">
                        <ul>
                            <li><a class="horizontal-thumb active" data-target="#best-seller-single-product-slider" data-slide="0" href="#slide1"><img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/gallery-thumb-01.jpg" /></a></li>
                            <li><a class="horizontal-thumb" data-target="#best-seller-single-product-slider" data-slide="1" href="#slide2"><img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/gallery-thumb-01.jpg" /></a></li>
                            <li><a class="horizontal-thumb" data-target="#best-seller-single-product-slider" data-slide="2" href="#slide3"><img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/gallery-thumb-01.jpg" /></a></li>
                        </ul>
                    </div><!-- /.gallery-thumbs -->

                    <div class="body">
                        <div class="label-discount clear"></div>
                        <div class="title">
                            <a href="javascript:undefined">CPU intel core i5-4670k 3.4GHz BOX B82-12-122-41</a>
                        </div>
                        <div class="brand">sony</div>
                    </div>
                    <input type="hidden" id="product_id" class="product_id" value="2" />
                    <div class="prices text-right">
                        <div class="price-current inline">$1199.00</div>
                        <a href="javascript:undefined" class="le-button big inline add_cart">加入購物車</a>
                    </div>
                </div><!-- /.product-item-holder -->
            </div><!-- /.col -->

        </div><!-- /.product-grid-holder -->
    </div><!-- /.container -->
</section><!-- /#bestsellers -->