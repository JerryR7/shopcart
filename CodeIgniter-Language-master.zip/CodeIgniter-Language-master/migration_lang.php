<?php

$lang['migration_none_found'] = "沒有發現任何 Migrations";
$lang['migration_not_found'] = "此 Migration 不存在";
$lang['migration_multiple_version'] = "多重 migrations 擁有相同的版本號碼: %d";
$lang['migration_class_doesnt_exist'] = "Migration 類別 \"%s\" 不存在";
$lang['migration_missing_up_method'] = "Migration 類別 \"%s\" i缺少 'up' 方法";
$lang['migration_missing_down_method'] = "Migration 類別 \"%s\" 缺少 'down' 方法";
$lang['migration_invalid_filename'] = "Migration \"%s\" 包含無效的欄位名稱";


/* End of file migration_lang.php */
/* Location: ./system/language/zh-TW/migration_lang.php */
