<div class="col-sm-4 col-md-3  no-margin product-item-holder hover">
    <div class="product-item">
        <div class="ribbon red"><span>優惠</span></div>
        <div class="image">
            <img alt="" src="<?php echo base_url();?>assets/images/blank.gif" data-echo="<?php echo base_url();?>assets/images/products/product-01.jpg" />
        </div>
        <div class="body">
            <div class="label-discount green">-50% 優惠</div>
            <div class="title">
                <a href="javascript:undefined">VAIO Fit Laptop - Windows 8 SVF14322CXW</a>
            </div>
            <div class="brand">sony</div>
        </div>
        <div class="prices">
            <div class="price-prev">$1399.00</div>
            <div class="price-current pull-right">$1199.00</div>
        </div>

        <div class="hover-area">
            <input type="hidden" id="product_id" class="product_id" value="1" />
            <div class="add-cart-button">
                <a href="javascript:undefined" class="le-button add_cart">加入購物車</a>
            </div>
            <div class="wish-compare">
                <a class="btn-add-to-wishlist add_favor" href="javascript:undefined">加入喜歡清單</a>
                <a class="btn-add-to-compare add_compare" href="javascript:undefined">加入比較</a>
            </div>
        </div>
    </div>
</div>