<?php
  $config = array(
    'protocol' => 'smtp',
    'smtp_host' => 'ssl://smtp.googlemail.com',
    'smtp_user' => 'leesu88@gmail.com',
    'smtp_pass' => 'audilgul',
    'smtp_port' => '465',
    'smtp_timeout' => 5,
    'validate' => TRUE,
  );

?>