<?php
  $config = array(
    'upload_path' => './images/action/',
    'allowed_types' => 'gif|jpg|png',
    'max_size' => 10240,
    'remove_spaces' => TRUE,
    'encrypt_name' => TRUE
  );

?>